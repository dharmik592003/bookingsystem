@php
    use App\Status;

@endphp
<table id="example" class="table table-striped" style="width:100%">

    <thead>
        <tr>
            <th scope="col">#</th>
       
            <th scope="col">services</th>
            <th scope="col">status</th>
            <th scope="col">price </th>
            <th scope="col">from </th>
            <th scope="col">to</th>
            <th scope="col">actions</th>
        </tr>
    </thead>
    </thead>
    <tbody>
        @foreach ($users as $user)
     
            <tr>
        
                                   
                        <th scope="row" class="form" >{{ $loop->index + 1}}</th>
                      
                        <td>{{ $user->service->name }}</td>
                        <td name="status" id="status" value="">{{ $user->status }}</td>
                        <td>{{ $user->service->price }} ₹</td>
                        <td>{{ $user->from }}</td>
                        <td>{{ $user->to }}</td>
                        <td>
                         <a href="" class="btn btn-primary">edit</a><a href="" class="btn btn-danger">cancel</a>
                        </td>
                    
            </tr>
            
        @endforeach
    </tbody>
</table>
