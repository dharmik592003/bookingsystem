@extends('user.layout')
@section('main')
  @include('components.agency-customer')
@endsection