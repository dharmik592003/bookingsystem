@extends('user.layout')
@section('main')


  <div class="app-content-header">
    <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-6">
      <!--begin::Small Box Widget 2-->

      <form id="hmsearchfrm" class="d-flex   flex-row align-items-center" action="" style="gap: 10px;" method="post">
        <!--begin::Small Box Widget 2-->
        <div class="small-box row  searchfrm text-bg-primary">
        <div class="inner d-flex">
          <div class="form-col">
          <i class="bi bi-geo-alt"></i>
          <label for="formSearchUpCity3">Country</label>
          <div id="inxUsrctyList01" class="has-icon">
            <select name="country_id" onchange="updateTextInput()" class="form-select" id="inputState">
            <option value="">Select Country</option>
            @foreach ($country as $cn)
        <option value="{{$cn->id}}">{{$cn->name}}</option>
      @endforeach
            </select>
          </div>
          <a href="javascript:;" class="hmdtct1mob"><i class="fa fa-crosshairs"></i></a>
          </div>
          <div class="form-col">
          <i class="bi bi-geo-alt"></i>

          <label for="">State</label>
          <div id="inxUsrctyList01" class="has-icon">
            <select name="state_id" onchange="upd()" class="form-select" id="inputState2">
            <option value="">Select State</option>
            </select>
          </div>
          <a href="javascript:;" class="hmdtct1mob"><i class="fa fa-crosshairs"></i></a>
          </div>
          <div class="form-col">
          <i class="bi bi-geo-alt"></i>
          <label for="formSearchUpCity3">City</label>
          <div id="inxUsrctyList01" class="has-icon">
            <select name="city_id" class="form-select" id="inputcities">
            <option value="">Select City</option>
            </select>
          </div>
          <a href="javascript:;" class="hmdtct1mob"><i class="fa fa-crosshairs"></i>
          </a>
          </div>
          <div class="form-col">
          <i class="bi bi-calendar"></i>
          <label for="">Pick Up Date</label>
          <div>
            <input type="date" class="" name="picking_up_date" style="height:36px;
                            border-radius:5px; border:0px;" value="2025-02-24" id="pckdateNsd"
            autocomplete="off" min="2025-02-24" aria-label="pick up date">
          </div>
          </div>
          <div class="form-col">
          <i class="bi bi-clock"></i>
          <label for="">Pick Time</label>
          <select name="" class="form-select" id="">
            <option data-id="" data-value="-- select --">-- select
            --
            </option>
            <option class="" data-id="06:00" data-value="06:00 AM">
            06:00
            AM</option>
            <option class="" data-id="07:00" data-value="07:00 AM">
            07:00
            AM</option>
            <option class="" data-id="08:00" data-value="08:00 AM">
            08:00
            AM</option>
            <option class="" data-id="09:00" data-value="09:00 AM">
            09:00
            AM</option>
            <option class="" data-id="10:00" data-value="10:00 AM">
            10:00
            AM</option>
            <option class="" data-id="11:00" data-value="11:00 AM">
            11:00
            AM</option>
            <option class="" data-id="12:00" data-value="12:00 PM">
            12:00
            PM</option>
            <option class="active" data-id="13:00" data-value="01:00 PM">01:00 PM
            </option>
            <option class="" data-id="14:00" data-value="02:00 PM">
            02:00
            PM</option>
            <option class="" data-id="15:00" data-value="03:00 PM">
            03:00
            PM</option>
            <option class="" data-id="16:00" data-value="04:00 PM">
            04:00
            PM</option>
            <option class="" data-id="17:00" data-value="05:00 PM">
            05:00
            PM</option>
            <option class="" data-id="18:00" data-value="06:00 PM">
            06:00
            PM</option>
            <option class="" data-id="19:00" data-value="07:00 PM">
            07:00
            PM</option>
            <option class="" data-id="20:00" data-value="08:00 PM">
            08:00
            PM</option>
            <option class="" data-id="21:00" data-value="09:00 PM">
            09:00
            PM</option>
            <option class="" data-id="22:00" data-value="10:00 PM">
            10:00
            PM</option>
            <option class="" data-id="23:00" data-value="11:00 PM">
            11:00
            PM</option>
          </select>
          </div>
          <div class="form-col">
          <i class="bi bi-calendar"></i>
          <label for="">Drop Off Date</label>
          <div>
            <input type="date" style="height:36px;
                            border-radius:5px; border:0px;" name="dropping_off_date" value=""
            id="drpdateNsd" autocomplete="off" min="2025-02-24" aria-label="drop off date">
          </div>
          </div>
          <div class="form-col">
          <label for="">Drop Time</label>
          <select name="" class="form-select" id="">
            <option data-id="" data-value="-- select --">-- select
            --
            </option>
            <option class="" data-id="06:00" data-value="06:00 AM">
            06:00
            AM</option>
            <option class="" data-id="07:00" data-value="07:00 AM">
            07:00
            AM</option>
            <option class="" data-id="08:00" data-value="08:00 AM">
            08:00
            AM</option>
            <option class="" data-id="09:00" data-value="09:00 AM">
            09:00
            AM</option>
            <option class="" data-id="10:00" data-value="10:00 AM">
            10:00
            AM</option>
            <option class="" data-id="11:00" data-value="11:00 AM">
            11:00
            AM</option>
            <option class="" data-id="12:00" data-value="12:00 PM">
            12:00
            PM</option>
            <option class="active" data-id="13:00" data-value="01:00 PM">01:00 PM
            </option>
            <option class="" data-id="14:00" data-value="02:00 PM">
            02:00
            PM</option>
            <option class="" data-id="15:00" data-value="03:00 PM">
            03:00
            PM</option>
            <option class="" data-id="16:00" data-value="04:00 PM">
            04:00
            PM</option>
            <option class="" data-id="17:00" data-value="05:00 PM">
            05:00
            PM</option>
            <option class="" data-id="18:00" data-value="06:00 PM">
            06:00
            PM</option>
            <option class="" data-id="19:00" data-value="07:00 PM">
            07:00
            PM</option>
            <option class="" data-id="20:00" data-value="08:00 PM">
            08:00
            PM</option>
            <option class="" data-id="21:00" data-value="09:00 PM">
            09:00
            PM</option>
            <option class="" data-id="22:00" data-value="10:00 PM">
            10:00
            PM</option>
            <option class="" data-id="23:00" data-value="11:00 PM">
            11:00
            PM</option>
          </select>
          </div>
        </div>

        <div>
          <label class="btn text-light">
          <input type="checkbox" value="1" autocomplete="off"> vila
          </label>
          <i class="bi bi-car-front"></i>
          <label class="btn text-light">
          <input type="checkbox" value="2" autocomplete="off"> cars
          </label>
          <label class="btn text-light">
          <input type="checkbox" value="3" autocomplete="off"> bikes/scooters
          </label>
          <label class="btn text-light">
          <input type="checkbox" value="4" autocomplete="off"> jets
          </label>
          <label class="btn text-light">
          <input type="checkbox" value="5" autocomplete="off"> yatch
          </label>
        </div>

        <div class="form-col">
          <input type="hidden" name="_token" value="FCxHMHDtGqQODZaeEA7fY63Se04PDvv4nmC6wsdv">
          <button type="submit" class="btn btn-success" id="nl_hmseacrhFrmSbmt">Find
          services</button>
        </div>
      </form>

      <!--end::Small Box Widget 2-->
      </div>

    </div>
    </div>
  </div>
  <div class="container-fluid">
    @foreach ($services as $service)

    <div class="row  img-carousel-row " style="border: 1px solid red;height:500px;">
    <div class="lable">
      <label for="">{{ $service->name }}</label>
    </div>
    <div class="owl-carousel owl-theme  image-slide ">
      @foreach ($service->getservices as $subservices)
      <div class="card" style="width: 18rem;">
      <div class="slide-image">
      <img src="{{ $subservices->banner_photo }}" alt="" class="img-fluid" alt="image">
      </div>
      <div class="card-body">
      <h1>
      {{ $subservices->name }}
      </h1>
      <p class="card-text">{{$subservices->desc}}.</p>

      <a href="{{ $service->name }}/{{ $subservices->name }}" class="btn btn-primary">Check out</a>
      </div>
      </div>
    @endforeach
    </div>
    </div>
  @endforeach
  </div>

@endsection

@section('script')
  <!-- ChartJS -->
  <script>
    function updateTextInput() {
    const xhr = new XMLHttpRequest();
    var dropdown = document.getElementById('inputState');
    var dropdown2 = document.getElementById('inputState2');
    var value = dropdown.value;
    console.log(dropdown.value);
    $.ajax({
      headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
      },
      url: '/sendstates',
      data: { 'id': value },
      type: "get",
      cache: false,
      success: function (response) {
      console.log(response);
      $('#inputState2').html('<option value="">-- Select State --</option>');
      $.each(response.id, function (key, value) {
        $("#inputState2").append('<option value="' + value.id + '">' + value.name + '</option>');
      });
      },
      error: function (response) {
      console.log('not done');
      }
    });
    }

    function upd() {
    const xhr = new XMLHttpRequest();
    var dropdown = document.getElementById('inputState2');
    var dropdown2 = document.getElementById('inputcities');
    var value = dropdown.value;
    console.log(dropdown.value);

    $.ajax({
      headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
      },
      url: '/sendcity',
      data: { 'id': value },
      type: "get",
      cache: false,
      success: function (response) {
      console.log(response);
      $('#inputcities').html('<option value="">-- Select City --</option>');
      $.each(response.id, function (key, value) {
        $("#inputcities").append('<option value="' + value.id + '">' + value.name + '</option>');
      });
      },
      error: function (response) {
      console.log('not done');
      }
    });
    }
  </script>
@endsection