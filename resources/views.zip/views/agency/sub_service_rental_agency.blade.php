<!doctype html>
<html lang="en">
<!--begin::Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>service</title>
    <!--begin::Primary Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="title" content="AdminLTE v4 | Dashboard" />
    <meta name="author" content="ColorlibHQ" />
    <meta name="description"
        content="AdminLTE is a Free Bootstrap 5 Admin Dashboard, 30 example pages using Vanilla JS." />
    <meta name="keywords"
        content="bootstrap 5, bootstrap, bootstrap 5 admin dashboard, bootstrap 5 dashboard, bootstrap 5 charts, bootstrap 5 calendar, bootstrap 5 datepicker, bootstrap 5 tables, bootstrap 5 datatable, vanilla js datatable, colorlibhq, colorlibhq dashboard, colorlibhq admin dashboard" />
    <!--end::Primary Meta Tags-->
    <!--begin::Fonts-->
    <link rel="stylesheet" href="{{asset('admin/dist/css/index.css')}}" />
    <!--end::Fonts-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="{{asset('admin/dist/css/overlayscrollbars.min.css')}}" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->
    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="{{asset('admin/dist/css/bootstrap-icons.min.css')}}" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->
    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="{{asset('admin/dist/css/adminlte.css')}}" />
    <!--end::Required Plugin(AdminLTE)-->
    <!-- apexcharts -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="{{asset('admin/dist/css/style.css')}}" />
    <style>
        .owl-nav {
    top: -50px;
    position: absolute;
    margin: 0 !important;
    padding: 0 !important;
}
.owl-carousel .nav-button {
    height: 50px;
    width: 25px;
    cursor: pointer;
    top: 0px !important;
    background: transparent !important;
    font-size: 20px !important;
    width: fit-content;
}

.owl-carousel .owl-prev {
    left: 10px;
    margin: 0 !important;

}

.owl-nav button:hover {

background-color: transparent !important;

}
.owl-carousel .owl-next {
    right: 10px;
    margin: 0 !important;
}

    </style>

</head>


<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">

    @if(
        Session::has('fail')
    )
            <div class="alert alert-danger">
                {{Session::get('fail')}}
            </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="app-wrapper">



        @include('components.navbar')

        @if (Session::get('loginid') == 1)
            @include('components.sidebar')
        @elseif (Session::get('customer_id') == 2)
            @include('components.sidebar-customer')
        @elseif(Session::get('customer_id') == 3)
            @include('components.sidebar-agency')
        @endif
        <main class="app-main container-fluid p-0">

            <div class="background-img"
                style="background-image: url({{ asset($services->banner_photo) }});background-size: cover; ">
                <div class="row main-frame ">

                    <div class="col-xl-6  text-frame  bottom-0">
                        <div class="banner-text ">
                            <h1 class="text-white text-uppercase">{{ $services->name }}</h1>
                        </div>
                    </div>
                    <div class="col-xl-6 sub-frame flex-column gap-10">
                        @php
                            $arry = json_decode($services->service_images)
                        @endphp


                        <div class="row service-inquiry " style="border: 1px solid white; height:100%">
                            <div class="service-info">
                                <div class="service-description text-white">
                                    Explore our exclusive collection of over 350 of the best luxury villas in Ibiza.
                                    Every home in our portfolio is carefully chosen to ensure the highest standards
                                    and
                                    so you get the luxury vacation rental in Ibiza you have always been looking for
                                </div>
                                <div class="service-link">

                                    <a href="" class="text-white rounded-0 btn explore-btn">
                                        Explore
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="row  img-carousel-row " style="border: 1px solid red;">
                            <div class="owl-carousel owl-theme  image-slide">
                                @forEach($arry as $image)
                                    <div class="slide-image">
                                        <img src="{{ asset($image) }}" alt="" class="img-fluid">
                                    </div>

                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </main>


        @include('components.footer')
        <!--end::Footer-->
    </div>

    <!--end::App Wrapper-->
    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script src="{{asset('/admin/dist/js/overlayscrollbars.browser.es6.min.js')}}"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)--><!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script src="{{asset('/admin/dist/js/popper.min.js')}}"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)--><!--begin::Required Plugin(Bootstrap 5)-->
    <script src="{{asset('/admin/dist/js/bootstrap.min.js')}}"></script>
    <!--end::Required Plugin(Bootstrap 5)--><!--begin::Required Plugin(AdminLTE)-->
    <script src="{{asset('/admin/dist/js/adminlte.js')}}"></script>
    <!--end::Required Plugin(AdminLTE)--><!--begin::OverlayScrollbars Configure-->
    <script>
        const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
        const Default = {
            scrollbarTheme: 'os-theme-light',
            scrollbarAutoHide: 'leave',
            scrollbarClickScroll: true,
        };
        document.addEventListener('DOMContentLoaded', function () {
            const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
            if (sidebarWrapper && typeof OverlayScrollbarsGlobal?.OverlayScrollbars !== 'undefined') {
                OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
                    scrollbars: {
                        theme: Default.scrollbarTheme,
                        autoHide: Default.scrollbarAutoHide,
                        clickScroll: Default.scrollbarClickScroll,
                    },
                });
            }
        });
    </script>
    <!--end::OverlayScrollbars Configure-->
    <!-- OPTIONAL SCRIPTS -->
    <!-- sortablejs -->
    <script src="{{asset('admin/dist/js/Sortable.min.js')}}"></script>
    <!-- sortablejs -->
    <script>
        const connectedSortables = document.querySelectorAll('.connectedSortable');
        connectedSortables.forEach((connectedSortable) => {
            let sortable = new Sortable(connectedSortable, {
                group: 'shared',
                handle: '.card-header',
            });
        });

        const cardHeaders = document.querySelectorAll('.connectedSortable .card-header');
        cardHeaders.forEach((cardHeader) => {
            cardHeader.style.cursor = 'move';
        });
    </script>
    <!-- apexcharts -->
    <script src="{{asset('admin/dist/js/apexcharts.min.js')}}"
        integrity="sha256-+vh8GkaU7C9/wbSLIcwq82tQ2wTf44aOHA8HlBMwRI8=" crossorigin="anonymous">
        </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>



    <!-- ChartJS -->

    <!-- jsvectormap -->
    <script src="{{asset('admin/dist/js/jsvectormap.min.js')}}"></script>
    <script src="{{asset('admin/dist/js/world.js')}}"></script>
    <!-- jsvectormap -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"
        integrity="sha512-gY25nC63ddE0LcLPhxUJGFxa2GoIyA5FLym4UJqHDEMHjp8RET6Zn/SHo1sltt3WuVtqfyxECP38/daUc/WVEA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(function () {
            // Owl Carousel
            var owl = $(".owl-carousel");
            owl.owlCarousel({
                items: 2,
                dots: false,
                margin: 0,
                loop: true,
                nav: true,
                navText: ["<div class='nav-button d-flex owl-prev'>&larr; prev</div>", "<div class='nav-button d-flex owl-next'>next&rarr;</div>"]
            });
        });

    </script>
    <!--end::Script-->
</body>
<!--end::Body-->

</html>