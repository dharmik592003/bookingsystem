@extends('admin.layout')
@section('main')




        <!--end::Sidebar-->
        <!--begin::App Main-->
      
                @if (Session::get('loginid') == 1)
                    @include('admin.request-admin')
                @else
                    @include('user.request-customer')
                @endif


        <!--end::App Main-->
        <!--begin::Footer-->

        <!--end::Footer-->
  
    @endsection
    <!--end::App Wrapper-->
 @section('script')
 
 
    <script>

        $('.action').on('change', function () {

            // let id = $('.form').attr('data-id');
            var id = $(this).attr("data-id");
            console.log(id)
            let text = 'want to change?'
            let element = $('#form')
            if (confirm(text) == true) {
                text = "You pressed OK!";
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    },
                    type: "post",
                    url: id + "/status",

                    data: $(this).serialize(),
                    success: function (data) {
                        location.reload()
                    }

                });
                element.submit();
            } else {
                console.log("You canceled!");
            }

        });


    </script>

    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.bootstrap5.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.2.2/js/dataTables.buttons.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.2.2/js/buttons.bootstrap5.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.2.2/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.2.2/js/buttons.colVis.min.js"></script>

    <script>
        new DataTable('#example', {
            layout: {
                topStart: {
                    buttons: ['copy', 'excel', 'pdf', 'colvis']
                }
            }
        });
    </script>



@endsection




