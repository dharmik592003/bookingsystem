<!DOCTYPE html><!-- Last Published: Sun Jan 26 2025 21:22:52 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="www.louxibiza.com" data-wf-page="662ad12d3064b576f8313db5" data-wf-site="661681f6c60839d5881a158b"
  lang="en" data-wf-locale="en" class=" w-mod-js">

<head>
  <meta charset="utf-8">
  <title>Luxury Car Rental Ibiza</title>
  <meta
    content="Your luxury car rental in Ibiza ranging from exotic car rentals to elegant sedans. Elevate your luxury travel experience in Ibiza with us."
    name="description">
  <meta content="Luxury Car Rental Ibiza" property="og:title">
  <meta
    content="Your luxury car rental in Ibiza ranging from exotic car rentals to elegant sedans. Elevate your luxury travel experience in Ibiza with us."
    property="og:description">
  <meta content="Luxury Car Rental Ibiza" property="twitter:title">
  <meta
    content="Your luxury car rental in Ibiza ranging from exotic car rentals to elegant sedans. Elevate your luxury travel experience in Ibiza with us."
    property="twitter:description">
  <meta property="og:type" content="website">
  <meta content="summary_large_image" name="twitter:card">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="89RLXMMq4DyR0qKfRZ6xt2T-lDb9aZlGtGtSq0L25ps" name="google-site-verification">
  <link href="css/loux-website.webflow.88131bda9.css" rel="stylesheet" type="text/css">
  <style>
    @media (min-width:992px) {
      html.w-mod-js:not(.w-mod-ix) [data-w-id="cadd1a78-d3b1-44eb-c962-d64b8923210f"] {
        opacity: 0;
      }

      html.w-mod-js:not(.w-mod-ix) [data-w-id="c05e9057-a329-17f4-90f8-269cb3ce0af7"] {
        opacity: 0;
      }

      html.w-mod-js:not(.w-mod-ix) [data-w-id="bf72a209-5d68-1c3f-407f-83520bae2820"] {
        opacity: 0;
      }
    }

    @media (max-width:991px) and (min-width:768px) {
      html.w-mod-js:not(.w-mod-ix) [data-w-id="cadd1a78-d3b1-44eb-c962-d64b8923210f"] {
        opacity: 0;
      }

      html.w-mod-js:not(.w-mod-ix) [data-w-id="c05e9057-a329-17f4-90f8-269cb3ce0af7"] {
        opacity: 0;
      }

      html.w-mod-js:not(.w-mod-ix) [data-w-id="bf72a209-5d68-1c3f-407f-83520bae2820"] {
        opacity: 0;
      }
    }
  </style>
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous">
  <script src="js/webfont.js" type="text/javascript"></script>
  <script
    type="text/javascript">WebFont.load({ google: { families: ["Syne:regular,500,600,700,800", "Work Sans:regular,500,600,700,800,900"] } });</script>
  <script
    type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
  <link href="images/662f851a7e632ddfef0af67f_Favicon%20png%20%282%29.png" rel="shortcut icon" type="image/x-icon">
  <link href="images/662f84f85278598567c8b82b_Favicon%20png%20%281%29.png" rel="apple-touch-icon">
  <meta name="google-site-verification" content="PpOonkKg2U-R5QjhTCodAkni_fEWwqaXDxeIh49IrIE">

  <!-- Google tag (gtag.js) -->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=G-B5L33BY0ZS"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'G-B5L33BY0ZS');
  </script>
  <link rel="stylesheet" href="css/flatpickr.min.css">
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

  <script>

    var Webflow = Webflow || [];
    Webflow.push(function () {
      document.getElementsByClassName('date-villa').flatpickr({
        mode: "range",
        minDate: "today"

      });
    });

  </script>

  <link rel="stylesheet" href="css/datepicker.css">
  <!-- [Attributes by Finsweet] Custom Form Select -->
  <script defer="" src="js/selectcustom.js"></script>
  <!-- [Attributes by Finsweet] Form Submit Actions -->
  <script defer="" src="js/formsubmit.js"></script>

  <style>
    .w-input[disabled]:not(.w-input-disabled),
    .w-select[disabled]:not(.w-input-disabled),
    .w-input[readonly],
    .w-select[readonly],
    fieldset[disabled]:not(.w-input-disabled) .w-input,
    fieldset[disabled]:not(.w-input-disabled) .w-select {
      background-color: transparent;
    }
  </style>

</head>

<body>
@include('components.navbar-customer')
  <div class="nav-style w-embed w-script">
    <script>
      window.onscroll = function () {
        var currentScrollPos = window.pageYOffset;
        var whiteLogo = document.querySelector('.white-logo');
        var blackLogo = document.querySelector('.black-logo');
        var volmi = document.querySelector('.volm-i');
        var menuBigLine = document.querySelector('.menu-big-line');
        var menuSmallLine = document.querySelector('.menu-small-line');
        var blurBg = document.querySelector('.blur-bg'); // Додаємо посилання на блок з класом .blur-bg

        // Розраховуємо прокручений відсоток
        scrolledPercentage = (currentScrollPos / (document.documentElement.scrollHeight - window.innerHeight)) * 100;

        // Перевіряємо, чи прокручено більше 5% сторінки
        if (scrolledPercentage > 5) {
          if (prevScrollpos > currentScrollPos) {
            // Показуємо логотип з класом .black-logo, коли прокручуємо вгору
            blackLogo.style.display = "inline-block";
            whiteLogo.style.display = "none";

            // Змінюємо колір тексту елемента .volm-i
            volmi.style.color = "#454545";

            // Змінюємо фоновий колір елементів .menu-big-line та .menu-small-line
            menuBigLine.style.backgroundColor = "#454545";
            menuSmallLine.style.backgroundColor = "#454545";

            // Змінюємо opacity блоку з класом .blur-bg на 1
            blurBg.style.opacity = "1";
          } else {
            // Приховуємо логотип з класом .black-logo, коли прокручуємо вниз
            blackLogo.style.display = "none";
            whiteLogo.style.display = "inline-block";

            // Повертаємо колір тексту елемента .volm-i до замовчування
            volmi.style.color = "#000";

            // Повертаємо фоновий колір елементів .menu-big-line та .menu-small-line до білого
            menuBigLine.style.backgroundColor = "#fff";
            menuSmallLine.style.backgroundColor = "#fff";

            // Змінюємо opacity блоку з класом .blur-bg на 1
            blurBg.style.opacity = "0";
          }
        } else {
          // Якщо менше 5% не активуємо зміну кольору та логотипу
          blackLogo.style.display = "none";
          whiteLogo.style.display = "inline-block";
          volmi.style.color = "#fff"; // Початковий білий колір

          // Повертаємо фоновий колір елементів .menu-big-line та .menu-small-line до білого
          menuBigLine.style.backgroundColor = "#fff";
          menuSmallLine.style.backgroundColor = "#fff";

          // Змінюємо opacity блоку з класом .blur-bg на 1
          blurBg.style.opacity = "0";
        }

        prevScrollpos = currentScrollPos;
      }
    </script>
  </div>
  <div class="main_wrapper">
    <div class="section-bg-car">
      <div class="container">
        <div class="header_component">
          <div data-w-id="f76e83fd-2f8e-f72b-8001-101832e6921c" style="opacity:0" class="icon-wrap">
            <div class="icon-scroll">
              <div
                style="-webkit-transform:translate3d(-50%, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(-50%, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(-50%, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(-50%, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);opacity:1"
                class="scroll-dot"></div>
            </div>
          </div>
          <div data-w-id="f76e83fd-2f8e-f72b-8001-101832e6921f" style="opacity:0" class="header-title-car">
            <h1 class="h1-text">Luxury car rental ibiza</h1>
          </div>
          <div data-w-id="0dbc559f-5ed3-2456-c25c-02a493f7bbcb" style="opacity:0" class="header-info">
            <div class="text-p">Experience the thrill of the open road in Ibiza's most prestigious vehicles with our
              luxury car rental services. From exotic care rentals to elegant sedans, our fleet offers a curated
              selection of vehicles designed to elevate your ibiza travel experience.</div><a href="#form-car"
              class="button-car-ren w-inline-block">
              <div class="button-text">Make enquiry</div><img src="images/66182030a413fb8af9559e59_Arrow%201.svg"
                loading="lazy" alt="">
            </a>
          </div>
        </div>
      </div>
    </div>
    <div class="section-segment no--p">
      <div class="container container-no">
        <div class="margin-large">
          <div class="segment_component">
            <div data-w-id="cadd1a78-d3b1-44eb-c962-d64b8923210f" class="segment-item lux">
              <div class="segment-item-text">
                <div class="segment-item-title">Luxury</div>
                <div class="segment-item-prise">
                  <div class="segment-prise-text-m-copy">from:</div>
                  <div class="segment-prise-text-s">450€</div>
                  <div class="segment-prise-text-m-copy">/Day</div>
                </div>
              </div>
            </div>
            <div data-w-id="c05e9057-a329-17f4-90f8-269cb3ce0af7" class="segment-item prem">
              <div class="segment-item-text">
                <div class="segment-item-title">Premium</div>
                <div class="segment-item-prise">
                  <div class="segment-prise-text-m-copy">from:</div>
                  <div class="segment-prise-text-s">120€</div>
                  <div class="segment-prise-text-m-copy">/Day</div>
                </div>
              </div>
            </div>
            <div data-w-id="bf72a209-5d68-1c3f-407f-83520bae2820" class="segment-item stand">
              <div class="segment-item-text">
                <div class="segment-item-title">standard</div>
                <div class="segment-item-prise left-pos">
                  <div class="segment-prise-text-m-copy">from:</div>
                  <div class="segment-prise-text-s">40€</div>
                  <div class="segment-prise-text-m-copy">/Day</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="section-cars">
      <div class="container">
        <div class="margin-xlarge">
          <div class="cars_component">
            <div class="cars_component-heading">
              <div class="h2-title">Our selection of the most popular cars in Ibiza.</div>
            </div>
            <div class="cars_component-items">
              <div id="w-node-_2efdc111-0680-6679-ab25-a58f079929bb-f8313db5"
                class="collection-list-wrapper w-dyn-list">
                <div role="list" class="collection-list w-dyn-items">
                  <div role="listitem" class="w-dyn-item">
                    <div data-w-id="efca26a5-0e8f-4823-8852-3f13f9c7a31a" class="cars-item-big"><img
                        src="images/662adb7aa9dff2cc88997c07_Driver%20service.png" loading="lazy" alt=""
                        sizes="(max-width: 479px) 90vw, (max-width: 767px) 93vw, (max-width: 991px) 45vw, (max-width: 1279px) 46vw, (max-width: 1439px) 44vw, (max-width: 1919px) 640px, 800px"
                        srcset="images/662adb7aa9dff2cc88997c07_Driver%20service-p-500.png 500w, images/662adb7aa9dff2cc88997c07_Driver%20service.png 640w"
                        class="image-7">
                      <div class="cars-tem-text">
                        <div class="segment-item-title">Range Rover Sport</div>
                        <div class="segment-prise-text-s">from: 230€ /Day</div>
                      </div>
                    </div>
                  </div>
                  <div role="listitem" class="w-dyn-item">
                    <div data-w-id="efca26a5-0e8f-4823-8852-3f13f9c7a31a" class="cars-item-big"><img
                        src="images/662adbaded64f0571c64887e_Private%20Chef.png" loading="lazy" alt=""
                        sizes="(max-width: 479px) 90vw, (max-width: 767px) 93vw, (max-width: 991px) 45vw, (max-width: 1279px) 46vw, (max-width: 1439px) 44vw, (max-width: 1919px) 640px, 800px"
                        srcset="images/662adbaded64f0571c64887e_Private%20Chef-p-500.png 500w, images/662adbaded64f0571c64887e_Private%20Chef.png 640w"
                        class="image-7">
                      <div class="cars-tem-text">
                        <div class="segment-item-title">Mercedes G63</div>
                        <div class="segment-prise-text-s">from: 450€ /Day</div>
                      </div>
                    </div>
                  </div>
                  <div role="listitem" class="w-dyn-item">
                    <div data-w-id="efca26a5-0e8f-4823-8852-3f13f9c7a31a" class="cars-item-big"><img
                        src="images/662adbd4b7dcf669fb762cc4_Driver%20service.png" loading="lazy" alt=""
                        sizes="(max-width: 479px) 90vw, (max-width: 767px) 93vw, (max-width: 991px) 45vw, (max-width: 1279px) 46vw, (max-width: 1439px) 44vw, (max-width: 1919px) 640px, 800px"
                        srcset="images/662adbd4b7dcf669fb762cc4_Driver%20service-p-500.png 500w, images/662adbd4b7dcf669fb762cc4_Driver%20service.png 640w"
                        class="image-7">
                      <div class="cars-tem-text">
                        <div class="segment-item-title">Land Rover Defender</div>
                        <div class="segment-prise-text-s">from: 180€ /Day</div>
                      </div>
                    </div>
                  </div>
                  <div role="listitem" class="w-dyn-item">
                    <div data-w-id="efca26a5-0e8f-4823-8852-3f13f9c7a31a" class="cars-item-big"><img
                        src="images/662adbea347fdcefe9e41d7a_Private%20Chef.png" loading="lazy" alt=""
                        sizes="(max-width: 479px) 90vw, (max-width: 767px) 93vw, (max-width: 991px) 45vw, (max-width: 1279px) 46vw, (max-width: 1439px) 44vw, (max-width: 1919px) 640px, 800px"
                        srcset="images/662adbea347fdcefe9e41d7a_Private%20Chef-p-500.png 500w, images/662adbea347fdcefe9e41d7a_Private%20Chef.png 640w"
                        class="image-7">
                      <div class="cars-tem-text">
                        <div class="segment-item-title">Jeep Wrangler Cabrio</div>
                        <div class="segment-prise-text-s">from: 120€ /Day</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="w-dyn-list">
                <div role="list" class="collection-list-2 w-dyn-items">
                  <div role="listitem" class="collection-item w-dyn-item">
                    <div data-w-id="4668014e-bef4-6b5a-dc78-32c141e53ec4" class="cars-item"><img
                        src="images/662adc037ac6e5481efe701f_Villa%20Rental.png" loading="lazy" alt="" class="image-7">
                      <div class="cars-tem-text">
                        <div class="segment-item-title">Porsche 911 Cabrio</div>
                        <div class="segment-prise-text-s">from: 900€ /Day</div>
                      </div>
                    </div>
                  </div>
                  <div role="listitem" class="collection-item w-dyn-item">
                    <div data-w-id="4668014e-bef4-6b5a-dc78-32c141e53ec4" class="cars-item"><img
                        src="images/662adc18880daadc5505053e_Yacht%20Charter.png" loading="lazy" alt="" class="image-7">
                      <div class="cars-tem-text">
                        <div class="segment-item-title">Mini Cabrio</div>
                        <div class="segment-prise-text-s">from: 75€ /Day</div>
                      </div>
                    </div>
                  </div>
                  <div role="listitem" class="collection-item w-dyn-item">
                    <div data-w-id="4668014e-bef4-6b5a-dc78-32c141e53ec4" class="cars-item"><img
                        src="images/662adc421935a43a9af089af_Car%20Rental.png" loading="lazy" alt="" class="image-7">
                      <div class="cars-tem-text">
                        <div class="segment-item-title">BMW X1</div>
                        <div class="segment-prise-text-s">from: 100€ /Day</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="form-section" class="section-form">
      <div class="form-block">
        <div class="container">
          <div id="form-car" class="form_component-villa">
            <div class="form-left-component">
              <div class="h2-title title-white">Make enquiry</div>
              <div class="form-t">
                <div class="p-text p-white">Kindly fill out the following form so we can send you your personalised
                  offer.</div>
              </div>
              <div class="link-block"><a href="tel:+34653354920" class="link-item w-inline-block">
                  <div class="html-embed-4 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                      viewBox="0 0 18 18" fill="none">
                      <g clip-path="url(#clip0_1_236)">
                        <path
                          d="M16.5 12.6901V14.9401C16.5009 15.1489 16.4581 15.3557 16.3744 15.5471C16.2907 15.7385 16.168 15.9103 16.0141 16.0515C15.8602 16.1927 15.6784 16.3002 15.4806 16.3671C15.2827 16.434 15.073 16.4589 14.865 16.4401C12.5571 16.1893 10.3403 15.4007 8.39251 14.1376C6.58038 12.9861 5.04401 11.4497 3.89251 9.63757C2.62499 7.68098 1.83619 5.45332 1.59001 3.13507C1.57127 2.92767 1.59592 2.71864 1.66239 2.52129C1.72886 2.32394 1.83569 2.14259 1.97609 1.98879C2.11648 1.83499 2.28736 1.7121 2.47785 1.62796C2.66834 1.54382 2.87427 1.50027 3.08251 1.50007H5.33251C5.69649 1.49649 6.04935 1.62538 6.32533 1.86272C6.60131 2.10006 6.78157 2.42966 6.83251 2.79007C6.92748 3.51012 7.1036 4.21712 7.35751 4.89757C7.45842 5.16602 7.48026 5.45776 7.42044 5.73823C7.36062 6.01871 7.22166 6.27616 7.02001 6.48007L6.06751 7.43257C7.13518 9.31023 8.68985 10.8649 10.5675 11.9326L11.52 10.9801C11.7239 10.7784 11.9814 10.6395 12.2619 10.5796C12.5423 10.5198 12.8341 10.5417 13.1025 10.6426C13.783 10.8965 14.49 11.0726 15.21 11.1676C15.5743 11.219 15.9071 11.4025 16.1449 11.6832C16.3828 11.9639 16.5091 12.3223 16.5 12.6901Z"
                          stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                      </g>
                      <defs>
                        <clipPath id="clip0_1_236">
                          <rect width="18" height="18" fill="white"></rect>
                        </clipPath>
                      </defs>
                    </svg></div>
                </a><a href="mailto:requests@louxibiza.com" class="link-item w-inline-block">
                  <div class="html-embed-2 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                      viewBox="0 0 18 18" fill="none">
                      <path
                        d="M3 3H15C15.825 3 16.5 3.675 16.5 4.5V13.5C16.5 14.325 15.825 15 15 15H3C2.175 15 1.5 14.325 1.5 13.5V4.5C1.5 3.675 2.175 3 3 3Z"
                        stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                      <path d="M16.5 4.5L9 9.75L1.5 4.5" stroke="white" stroke-width="1.5" stroke-linecap="round"
                        stroke-linejoin="round"></path>
                    </svg></div>
                </a><a href="https://api.whatsapp.com/message/ZNOW6PKX4H32J1?autoload=1&app_absent=0" target="_blank"
                  class="link-item w-inline-block">
                  <div class="html-embed-3 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                      viewBox="0 0 18 18" fill="none">
                      <g clip-path="url(#clip0_1_240)">
                        <path
                          d="M15.3254 2.61392C13.6344 0.929306 11.385 0.000961305 8.99094 0C6.60223 0 4.34921 0.927521 2.64716 2.61172C0.942078 4.29881 0.00219727 6.54085 0 8.91664V8.91939V8.92104C0.000274658 10.359 0.378067 11.8096 1.0952 13.1337L0.0245819 18L4.94687 16.8804C6.19354 17.5086 7.58455 17.8399 8.9875 17.8404H8.99107C11.3794 17.8404 13.6324 16.9128 15.3347 15.2284C17.0413 13.54 17.9816 11.3008 17.9827 8.92351C17.9834 6.56296 17.0398 4.32216 15.3254 2.61392ZM8.99094 16.4355H8.98778C7.72806 16.435 6.47987 16.1187 5.37836 15.5207L5.14558 15.3943L1.87248 16.1388L2.58344 12.9077L2.44638 12.6714C1.76495 11.4962 1.40488 10.199 1.40488 8.91953C1.40749 4.77809 4.81023 1.40488 8.99066 1.40488C11.0102 1.4057 12.9078 2.18861 14.3339 3.60915C15.7814 5.05165 16.5784 6.93883 16.5777 8.9231C16.576 13.0655 13.1726 16.4355 8.99094 16.4355Z"
                          fill="white"></path>
                        <path
                          d="M6.54445 4.9873H6.15031C6.01312 4.9873 5.79037 5.03867 5.60196 5.2437C5.41341 5.44887 4.88208 5.94476 4.88208 6.95331C4.88208 7.96185 5.61913 8.93634 5.72185 9.07326C5.82471 9.21004 7.14458 11.3458 9.235 12.1674C10.9724 12.8502 11.326 12.7144 11.7029 12.6802C12.08 12.6461 12.9198 12.1844 13.0912 11.7059C13.2626 11.2273 13.2626 10.8169 13.2112 10.7312C13.1597 10.6458 13.0225 10.5946 12.817 10.4921C12.6112 10.3896 11.6032 9.88528 11.4147 9.81676C11.2261 9.74851 11.0891 9.71431 10.9519 9.91962C10.8147 10.1245 10.4108 10.5986 10.2908 10.7354C10.1709 10.8723 10.0509 10.8894 9.84515 10.7869C9.63943 10.684 8.98383 10.4637 8.19817 9.76553C7.58664 9.22212 7.16229 8.52916 7.04227 8.32399C6.92238 8.11896 7.0295 8.008 7.13263 7.90569C7.22505 7.81395 7.34988 7.68843 7.45274 7.56882C7.55547 7.44907 7.58472 7.36365 7.65338 7.22687C7.72191 7.09009 7.68758 6.97034 7.63622 6.86789C7.58472 6.7653 7.19003 5.75168 7.00711 5.34628H7.00725C6.85316 5.00488 6.69098 4.99335 6.54445 4.9873Z"
                          fill="white"></path>
                      </g>
                      <defs>
                        <clipPath id="clip0_1_240">
                          <rect width="18" height="18" fill="white"></rect>
                        </clipPath>
                      </defs>
                    </svg></div>
                </a></div>
            </div>
            <div class="form-right-component-villa">
              <div id="my-form-id" class="form-block-villa w-form">
                <form id="my-form-id2" name="wf-form-" data-name="" method="get" fs-formsubmit-element="form"
                  class="form-villa" data-wf-page-id="662ad12d3064b576f8313db5"
                  data-wf-element-id="372efba6-88fb-b9db-d8e6-37f764b4c87c">
                  <div class="form-up-block">
                    <div class="input-type"><input class="text-field label-text w-input" autocomplete="off"
                        maxlength="256" name="Name" data-name="Name" placeholder="Name*" type="text" id="Name-7"></div>
                    <div class="input-type"><input class="text-field label-text w-input" autocomplete="off"
                        maxlength="256" name="Surname" data-name="Surname" placeholder="Surname" type="text"
                        id="Surname-3" required=""></div>
                  </div>
                  <div class="form-up-block">
                    <div class="input-type"><input class="text-field label-text w-input" autocomplete="off"
                        maxlength="256" name="Email" data-name="Email" placeholder="Email*" type="text" id="Email-5">
                    </div>
                    <div class="ms-input-wrap-villa"><input class="date-villa w-input" maxlength="256" name="Data"
                        data-name="Data" placeholder="Select Date:" type="text" id="Date-2" required="">
                      <div class="html-embed-10 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                          viewBox="0 0 20 20" fill="none">
                          <path
                            d="M15.8333 3.33331H4.16667C3.24619 3.33331 2.5 4.07951 2.5 4.99998V16.6666C2.5 17.5871 3.24619 18.3333 4.16667 18.3333H15.8333C16.7538 18.3333 17.5 17.5871 17.5 16.6666V4.99998C17.5 4.07951 16.7538 3.33331 15.8333 3.33331Z"
                            stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                          <path d="M13.3334 1.66669V5.00002" stroke="white" stroke-width="1.5" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                          <path d="M6.66663 1.66669V5.00002" stroke="white" stroke-width="1.5" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                          <path d="M2.5 8.33331H17.5" stroke="white" stroke-width="1.5" stroke-linecap="round"
                            stroke-linejoin="round"></path>
                        </svg></div>
                    </div>
                  </div>
                  <div class="form-up-block">
                    <div class="div-block-81">
                      <div data-hover="false" data-delay="0" fs-selectcustom-element="dropdown"
                        data-w-id="b1791f74-d65b-eec6-7ad4-2524a40c6231" class="fs-select-1 w-dropdown">
                        <div class="fs-select_toggle-1 w-dropdown-toggle">
                          <div class="label-text">Select car category*</div>
                          <div>
                            <div class="html-embed-13 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="100%"
                                height="100%" viewBox="0 0 20 20" fill="none">
                                <path d="M5 7.5L10 12.5L15 7.5" stroke="white" stroke-width="1.5" stroke-linecap="round"
                                  stroke-linejoin="round"></path>
                              </svg></div>
                          </div>
                        </div>
                        <nav class="fs-select_list-1 w-dropdown-list"><select id="Select-car-category"
                            name="Select-car-category" data-name="Select car category"
                            class="fs-select_field-1 w-select">
                            <option value="">Select car category*</option>
                            <option value="Luxury">Luxury</option>
                            <option value="Premium">Premium</option>
                            <option value="standard">Standard</option>
                          </select><a href="#" class="fs-select_link-1 w-inline-block"></a></nav>
                      </div>
                    </div>
                  </div>
                  <div class="area-type-villa"><textarea id="Looking-for-a-specific-car"
                      name="Looking-for-a-specific-car" maxlength="5000" data-name="Looking for a specific car?"
                      placeholder="Looking for a specific car?" class="text-ared label-text w-input"></textarea></div>
                  <div class="field_parent captcha-block-copy">
                    <div id="captchatext" class="field-label asd">Field Label</div><input
                      class="field captcha-field w-input" maxlength="256" name="captca-field" data-name="captca-field"
                      placeholder="" type="text" id="captchainput" required="">
                  </div><input type="submit" data-wait="SUBMIT" class="contact-submit w-button" value="Submit">
                  <div class="w-embed">
                    <style>
                      textarea {
                        resize: none;
                      }

                      select option {
                        background-color: white;
                        /* Білий фон */
                        color: black;
                        /* Чорний текст */
                        font-size: 20px;
                        /* Розмір тексту 20px */
                        font-weight: normal;
                        display: block;
                        min-height: 1.2em;
                        padding: 16px 2px;
                        /* Відступи по 16px зверху і знизу, 2px зліва і справа */
                        border-radius: 0;
                        /* Видалення радіусу бордера */
                        white-space: nowrap;
                      }

                      select option[value] {
                        padding: 8px 2px 8px 15px;
                        /* Відступи: верх 8px, право 2px, низ 8px, ліво 15px */
                      }

                      select option:hover {
                        color: #454545;
                        /* Змінюємо колір тексту при наведенні на #454545 */
                      }

                      .w-input[disabled]:not(.w-input-disabled),
                      .w-select[disabled]:not(.w-input-disabled),
                      .w-input[readonly],
                      .w-select[readonly],
                      fieldset[disabled]:not(.w-input-disabled) .w-input,
                      fieldset[disabled]:not(.w-input-disabled) .w-select {
                        background-color: transparent;
                      }
                    </style>
                  </div>
                </form>
                <div class="success-message w-form-done">
                  <div class="succes-div">
                    <div class="succes-m-block suc2">
                      <div class="h3-title h3-upper">Thank you!</div>
                      <div class="p-small-s no-h black-p">Your email has been sent. We will send you a letter to your
                        email soon.</div>
                      <div fs-formsubmit-element="reset" data-w-id="372efba6-88fb-b9db-d8e6-37f764b4c89a"
                        class="success-close-m w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="33" height="33"
                          viewBox="0 0 33 33" fill="none">
                          <rect x="27.0403" y="27.5137" width="31.1508" height="0.677191"
                            transform="rotate(-135 27.0403 27.5137)" fill="#454545"></rect>
                          <rect x="5.01343" y="27.5137" width="31.1508" height="0.677191"
                            transform="rotate(-45 5.01343 27.5137)" fill="#454545"></rect>
                        </svg></div>
                    </div>
                  </div>
                </div>
                <div class="w-form-fail">
                  <div>Oops! Something went wrong while submitting the form.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div><img src="images/662bc8a61610b4505ce8c0d6_Logo.svg" loading="lazy" alt="" class="image-8">
    </div>
    <div class="section-faq">
      <div class="container">
        <div class="faq_component">
          <div class="faq_left-component">
            <div class="h2-title">F.A.Q</div>
          </div>
          <div class="faq_right-component">
            <div data-hover="false" data-delay="500" data-w-id="e655fcae-6c5d-468c-6f83-4f119c347a1a"
              class="dropdown-2 w-dropdown">
              <div class="dropdown-toggle-2 w-dropdown-toggle">
                <div class="h3-title h3-droptext">How does the booking process work?</div>
                <div class="dropdown-toggl-ico">
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-down"></div>
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-up"></div>
                </div>
              </div>
              <nav style="height:0px" class="dropdown-list-2 w-dropdown-list">
                <div class="p-small-s no-h pup24">To successfully confirm your luxury car rental in Ibiza, simply send
                  us your car rental request, and we'll handpick exclusive car options tailored to your preferences.
                  Once you've chosen your desired option we will send you a payment link for a 100% deposit, securing
                  your chosen luxury car.<br></div>
              </nav>
            </div>
            <div data-hover="false" data-delay="500" data-w-id="e655fcae-6c5d-468c-6f83-4f119c347a27"
              class="dropdown-2 w-dropdown">
              <div class="dropdown-toggle-2 w-dropdown-toggle">
                <div class="h3-title h3-droptext">Is it possible to have my car delivered to my villa or to the airport?
                </div>
                <div class="dropdown-toggl-ico">
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-down"></div>
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-up"></div>
                </div>
              </div>
              <nav style="height:0px" class="dropdown-list-2 w-dropdown-list">
                <div class="p-small-s no-h pup24">Absolutely, our luxury cars can be delivered to your desired location
                  for an additional fee. Our standard rental procedure involves picking up the car at our rental
                  company, which you can reach conveniently via taxi or by our in-house shuttle service.</div>
              </nav>
            </div>
            <div data-hover="false" data-delay="500" data-w-id="e655fcae-6c5d-468c-6f83-4f119c347a34"
              class="dropdown-2 w-dropdown">
              <div class="dropdown-toggle-2 w-dropdown-toggle">
                <div class="h3-title h3-droptext">Which cars are the best for Ibiza?</div>
                <div class="dropdown-toggl-ico">
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-down"></div>
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-up"></div>
                </div>
              </div>
              <nav style="height:0px" class="dropdown-list-2 w-dropdown-list">
                <div class="p-small-s no-h pup24">Our general recommendation for the perfect luxury car in Ibiza is to
                  opt for SUVs due to the numerous off-road routes leading to beaches and villas. The roads on Ibiza are
                  mostly very well prepared, with two-lane highways connecting the south with the north of the island.
                  Only the so called “caminos”, which translates “gravel” or “dirt road” leading to some remote houses
                  and beaches can sometimes be a little bit tricky. If you consider staying in a villa in a more remote
                  area, just ask us. We will be happy to help you choose the right car for your stay.</div>
              </nav>
            </div>
            <div data-hover="false" data-delay="500" data-w-id="e655fcae-6c5d-468c-6f83-4f119c347a41"
              class="dropdown-2 w-dropdown">
              <div class="dropdown-toggle-2 w-dropdown-toggle">
                <div class="h3-title h3-droptext">Can I add a driver to my desired car?</div>
                <div class="dropdown-toggl-ico">
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-down"></div>
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-up"></div>
                </div>
              </div>
              <nav style="height:0px" class="dropdown-list-2 w-dropdown-list">
                <div class="p-small-s no-h pup24">If you wish to book a dedicated private chauffeur in Ibiza together
                  with your preferred vehicle, this is of course also possible (at an extra cost). Just ask us and we
                  will arrange it.<br></div>
              </nav>
            </div>
            <div data-hover="false" data-delay="500" data-w-id="e655fcae-6c5d-468c-6f83-4f119c347a4e"
              class="dropdown-2 drop-last w-dropdown">
              <div class="dropdown-toggle-2 w-dropdown-toggle">
                <div class="h3-title fix-w h3-droptext">Is there an insurance for the cars?</div>
                <div class="dropdown-toggl-ico">
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-down"></div>
                  <div
                    style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"
                    class="plus-up"></div>
                </div>
              </div>
              <nav style="height:0px" class="dropdown-list-2 w-dropdown-list">
                <div class="p-small-s no-h pup24">Depending on your chosen category of car rental, you may select no
                  insurance, although we strongly advise opting for full insurance in Ibiza due to high traffic and
                  potential risks.<br>‍<br>Our exotic cars require a security deposit due on the rental day.<br>‍</div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="section-footer">
      <div class="container">
        <div class="margin-medium">
          <div class="footer_component">
            <div class="footer-up-component"><a id="w-node-d10716dd-0aab-b7c5-d0dc-785b0eb9727c-0eb97277" href="#"
                class="footer-logo w-inline-block"><img src="images/661cc1fe8b5bdd7f3393b8ab_Logo%20Ibiza.svg"
                  loading="lazy" alt=""></a>
              <div class="footer-center">
                <div class="footer-link-block">
                  <div class="footer-link-head">
                    <div class="title-small">Book</div>
                  </div>
                  <div class="footer-link-content"><a href="/villa-rentals" class="link-large">Villa Rentals</a><a
                      href="/yacht-charter" class="link-large">Yacht Charter</a><a href="/car-rentals"
                      aria-current="page" class="link-large w--current">Car Rentals</a><a href="/luxury-services"
                      class="link-large">LUXURY SERVICES</a></div>
                </div>
                <div class="footer-link-block">
                  <div class="footer-link-head">
                    <div class="title-small">Links</div>
                  </div>
                  <div class="footer-link-content"><a href="/" class="link-large">Homepage</a><a href="/about-us"
                      class="link-large">WHO ARE WE?</a><a href="/privacy-policy" class="link-large">PRIVACY POLICY</a>
                  </div>
                </div>
              </div>
              <div id="w-node-d10716dd-0aab-b7c5-d0dc-785b0eb97295-0eb97277" class="footer-right">
                <div class="div-block-4">
                  <div class="div-block-3">
                    <div class="title-small">We’d love to hear from you!</div>
                  </div>
                  <div class="form-block-2 w-form">
                    <form id="wf-form-" name="wf-form-" data-name="" method="get" fs-formsubmit-element="form"
                      class="form" data-wf-page-id="662ad12d3064b576f8313db5"
                      data-wf-element-id="d10716dd-0aab-b7c5-d0dc-785b0eb9729b">
                      <div class="form-up-block">
                        <div class="input-type input-footer"><input class="text-field label-text footer-text-l w-input"
                            autocomplete="off" maxlength="256" name="Name" data-name="Name" placeholder="Name*"
                            type="text" id="Name-6"></div>
                        <div class="input-type"><input class="text-field label-text footer-text-l w-input"
                            autocomplete="off" maxlength="256" name="Email" data-name="Email" placeholder="Email*"
                            type="email" id="Email-6" required=""></div>
                      </div>
                      <div class="area-type"><textarea id="Message-5" name="Message" maxlength="5000"
                          data-name="Message" placeholder="Message"
                          class="text-ared label-text footer-labl w-input"></textarea></div>
                      <div data-w-id="d10716dd-0aab-b7c5-d0dc-785b0eb972a3" class="div-block-78"><input type="submit"
                          data-wait="Please wait..." class="contact-submit submit-footer w-button" value="Submit">
                        <div class="icon-btn w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="38" height="13"
                            viewBox="0 0 38 13" fill="none">
                            <path
                              d="M37.5303 7.03033C37.8232 6.73744 37.8232 6.26256 37.5303 5.96967L32.7574 1.1967C32.4645 0.903806 31.9896 0.903806 31.6967 1.1967C31.4038 1.48959 31.4038 1.96447 31.6967 2.25736L35.9393 6.5L31.6967 10.7426C31.4038 11.0355 31.4038 11.5104 31.6967 11.8033C31.9896 12.0962 32.4645 12.0962 32.7574 11.8033L37.5303 7.03033ZM0 7.25H37V5.75H0V7.25Z"
                              fill="currentColor"></path>
                          </svg></div>
                      </div>
                      <div class="w-embed">
                        <style>
                          textarea {
                            resize: none;
                          }
                        </style>
                      </div>
                    </form>
                    <div class="w-form-done">
                      <div>Thank you! Your submission has been received!</div>
                    </div>
                    <div class="w-form-fail">
                      <div>Oops! Something went wrong while submitting the form.</div>
                    </div>
                  </div>
                </div>
                <div class="footer-info">
                  <div class="footer-info-link"><a href="tel:+34653354920" class="footer-link-com w-inline-block">
                      <div class="html-embed-7 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="19"
                          viewBox="0 0 18 19" fill="none">
                          <path
                            d="M16.4999 13.1901V15.4401C16.5008 15.6489 16.458 15.8557 16.3743 16.0471C16.2907 16.2385 16.1679 16.4103 16.014 16.5515C15.8601 16.6927 15.6784 16.8002 15.4805 16.8671C15.2826 16.934 15.073 16.9589 14.8649 16.9401C12.5571 16.6893 10.3402 15.9007 8.39245 14.6376C6.58032 13.4861 5.04395 11.9497 3.89245 10.1376C2.62493 8.18098 1.83613 5.95332 1.58995 3.63507C1.57121 3.42767 1.59586 3.21864 1.66233 3.02129C1.72879 2.82394 1.83563 2.64259 1.97602 2.48879C2.11642 2.33499 2.2873 2.2121 2.47779 2.12796C2.66828 2.04382 2.87421 2.00027 3.08245 2.00007H5.33245C5.69643 1.99649 6.04929 2.12538 6.32527 2.36272C6.60125 2.60006 6.78151 2.92966 6.83245 3.29007C6.92742 4.01012 7.10354 4.71712 7.35745 5.39757C7.45836 5.66602 7.4802 5.95776 7.42038 6.23823C7.36056 6.51871 7.2216 6.77616 7.01995 6.98007L6.06745 7.93257C7.13512 9.81023 8.68979 11.3649 10.5675 12.4326L11.5199 11.4801C11.7239 11.2784 11.9813 11.1395 12.2618 11.0796C12.5423 11.0198 12.834 11.0417 13.1024 11.1426C13.7829 11.3965 14.4899 11.5726 15.21 11.6676C15.5743 11.719 15.907 11.9025 16.1448 12.1832C16.3827 12.4639 16.5091 12.8223 16.4999 13.1901Z"
                            stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                          </path>
                        </svg></div>
                      <div class="phone-text">+34 653 354 920</div>
                    </a><a href="mailto:requests@louxibiza.com" class="footer-link-com w-inline-block">
                      <div class="html-embed-7 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="19"
                          viewBox="0 0 18 19" fill="none">
                          <path
                            d="M3 3.5H15C15.825 3.5 16.5 4.175 16.5 5V14C16.5 14.825 15.825 15.5 15 15.5H3C2.175 15.5 1.5 14.825 1.5 14V5C1.5 4.175 2.175 3.5 3 3.5Z"
                            stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                          </path>
                          <path d="M16.5 5L9 10.25L1.5 5" stroke="currentColor" stroke-width="1.5"
                            stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg></div>
                      <div class="links-medium">requests@louxibiza.com</div>
                    </a></div>
                  <div class="footer-info-link"><a
                      href="https://api.whatsapp.com/message/ZNOW6PKX4H32J1?autoload=1&app_absent=0" target="_blank"
                      class="footer-link-com w-inline-block">
                      <div class="html-embed-7 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="19"
                          viewBox="0 0 18 19" fill="none">
                          <g clip-path="url(#clip0_1_139)">
                            <path
                              d="M15.3254 3.11392C13.6344 1.42931 11.385 0.500961 8.99094 0.5C6.60223 0.5 4.34921 1.42752 2.64716 3.11172C0.942078 4.79881 0.00219727 7.04085 0 9.41664V9.41939V9.42104C0.000274658 10.859 0.378067 12.3096 1.0952 13.6337L0.0245819 18.5L4.94687 17.3804C6.19354 18.0086 7.58455 18.3399 8.9875 18.3404H8.99107C11.3794 18.3404 13.6324 17.4128 15.3347 15.7284C17.0413 14.04 17.9816 11.8008 17.9827 9.42351C17.9834 7.06296 17.0398 4.82216 15.3254 3.11392ZM8.99094 16.9355H8.98778C7.72806 16.935 6.47987 16.6187 5.37836 16.0207L5.14558 15.8943L1.87248 16.6388L2.58344 13.4077L2.44638 13.1714C1.76495 11.9962 1.40488 10.699 1.40488 9.41953C1.40749 5.27809 4.81023 1.90488 8.99066 1.90488C11.0102 1.9057 12.9078 2.68861 14.3339 4.10915C15.7814 5.55165 16.5784 7.43883 16.5777 9.4231C16.576 13.5655 13.1726 16.9355 8.99094 16.9355Z"
                              fill="currentColor"></path>
                            <path
                              d="M6.54445 5.4873H6.15031C6.01312 5.4873 5.79037 5.53867 5.60196 5.7437C5.41341 5.94887 4.88208 6.44476 4.88208 7.45331C4.88208 8.46185 5.61913 9.43634 5.72185 9.57326C5.82471 9.71004 7.14458 11.8458 9.235 12.6674C10.9724 13.3502 11.326 13.2144 11.7029 13.1802C12.08 13.1461 12.9198 12.6844 13.0912 12.2059C13.2626 11.7273 13.2626 11.3169 13.2112 11.2312C13.1597 11.1458 13.0225 11.0946 12.817 10.9921C12.6112 10.8896 11.6032 10.3853 11.4147 10.3168C11.2261 10.2485 11.0891 10.2143 10.9519 10.4196C10.8147 10.6245 10.4108 11.0986 10.2908 11.2354C10.1709 11.3723 10.0509 11.3894 9.84515 11.2869C9.63943 11.184 8.98383 10.9637 8.19817 10.2655C7.58664 9.72212 7.16229 9.02916 7.04227 8.82399C6.92238 8.61896 7.0295 8.508 7.13263 8.40569C7.22505 8.31395 7.34988 8.18843 7.45274 8.06882C7.55547 7.94907 7.58472 7.86365 7.65338 7.72687C7.72191 7.59009 7.68758 7.47034 7.63622 7.36789C7.58472 7.2653 7.19003 6.25168 7.00711 5.84628H7.00725C6.85316 5.50488 6.69098 5.49335 6.54445 5.4873Z"
                              fill="currentColor"></path>
                          </g>
                          <defs>
                            <clipPath id="clip0_1_139">
                              <rect width="18" height="18" fill="white" transform="translate(0 0.5)"></rect>
                            </clipPath>
                          </defs>
                        </svg></div>
                      <div class="links-medium">WhatsApp</div>
                    </a><a href="https://www.instagram.com/louxibiza/?hl=ru" target="_blank"
                      class="footer-link-com w-inline-block">
                      <div class="html-embed-7 w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="19"
                          viewBox="0 0 18 19" fill="none">
                          <path
                            d="M12.75 2H5.25C3.17893 2 1.5 3.67893 1.5 5.75V13.25C1.5 15.3211 3.17893 17 5.25 17H12.75C14.8211 17 16.5 15.3211 16.5 13.25V5.75C16.5 3.67893 14.8211 2 12.75 2Z"
                            stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                          </path>
                          <path
                            d="M12 9.02773C12.0926 9.65191 11.986 10.2894 11.6953 10.8495C11.4047 11.4096 10.9449 11.8638 10.3812 12.1475C9.8176 12.4312 9.17886 12.5299 8.55586 12.4297C7.93287 12.3294 7.35734 12.0353 6.91115 11.5891C6.46496 11.1429 6.17082 10.5674 6.07058 9.94439C5.97033 9.32139 6.06907 8.68265 6.35277 8.11901C6.63647 7.55537 7.09066 7.09553 7.65076 6.80491C8.21086 6.51428 8.84834 6.40767 9.47252 6.50023C10.1092 6.59464 10.6987 6.89132 11.1538 7.34646C11.6089 7.80159 11.9056 8.39103 12 9.02773Z"
                            stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                          </path>
                          <path d="M13.125 5.375H13.1325" stroke="currentColor" stroke-width="1.5"
                            stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg></div>
                      <div class="links-medium">Instagram</div>
                    </a></div>
                </div>
              </div>
            </div>
            <div class="footer-dowm-component">
              <div class="div-block-80">
                <div class="p-small-s no-h">© 2024 - LOUX IBIZA. All rights reserved.</div>
              </div><a href="https://zipl.pro/" target="_blank" class="company-link w-inline-block">
                <div class="p-small-s no-h">Made by ZIPL</div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="js/jquery-3.5.1.min.dc5e7f18c8.js" type="text/javascript" crossorigin="anonymous"></script>
  <script src="js/webflow.4bbd219a.ad537dcdd85f9772.js" type="text/javascript"></script>
  <meta name="google-site-verification" content="PpOonkKg2U-R5QjhTCodAkni_fEWwqaXDxeIh49IrIE">
  <script>
    Webflow.push(function () {
      $('.menu-button').click(function (e) {
        e.preventDefault();
        if ($('.menu-button').hasClass('w--open')) {
          $('body').css('overflow', 'auto');
        } else {
          $('body').css('overflow', 'hidden');
        }
      });
    });


  </script>

  <!-- Maths Captcha -- ukasha.design -->
  <script>
    $(function () {
      $('#my-form-id2').ebcaptcha(); //Add this ID to your Form, or replace this ID with your Form ID
    });

    (function ($) {

      jQuery.fn.ebcaptcha = function (options) {

        var element = this;
        var input = this.find('#captchainput'); // Add this ID to your input field which user will use to answer the question
        var label = this.find('#captchatext'); // Add this ID to the field label -- this will have the maths question
        $(element).find('input[type=submit]').attr('disabled', 'disabled');

        var randomNr1 = 0;
        var randomNr2 = 0;
        var totalNr = 0;


        randomNr1 = Math.floor(Math.random() * 10);
        randomNr2 = Math.floor(Math.random() * 10);
        totalNr = randomNr1 + randomNr2;
        var texti = "What is " + randomNr1 + " + " + randomNr2;
        $(label).text(texti);


        $(input).keyup(function () {

          var nr = $(this).val();
          if (nr == totalNr) {
            $(element).find('input[type=submit]').removeAttr('disabled');
          }
          else {
            $(element).find('input[type=submit]').attr('disabled', 'disabled');
          }

        });

        $(document).keypress(function (e) {
          if (e.which == 13) {
            if ((element).find('input[type=submit]').is(':disabled') == true) {
              e.preventDefault();
              return false;
            }
          }

        });

      };

    })(jQuery);
  </script>
</body>

</html>