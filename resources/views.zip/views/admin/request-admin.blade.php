
@php
    use App\Status;

@endphp
<table id="example" class="table table-striped" style="width:100%">

    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">name</th>
            <th scope="col">email</th>
            <th scope="col">services</th>
            <th scope="col">agency</th>
            <th scope="col">from</th>
            <th scope="col">to</th>
            <th scope="col">status</th>
            <th scope="col">actions</th>
        </tr>
    </thead>
    </thead>
    <tbody>
     
        @foreach ($ids as $id)

            <tr>
             
                    
                        <th scope="row" class="form" >{{ $loop->index + 1}}</th>
                        <td>{{ $id->customer->name }}</td>
                        <td>{{ $id->customer->email }}</td>
                        <td>{{ $id->service->name}}</td>
                        <td>{{ $id->service->service->name}}</td>
                        <td>{{ $id->from}}</td>
                        <td>{{ $id->to}}</td>
                        <td name="status" id="status" value="">{{ $id->status }}</td>
                        <td>

                            <select name="status" data-id="{{$id->id}}" class="action">
                                <option selected>Action</option>
                                @foreach (Status::cases() as $status)
                                    <option value="{{ $status }}">{{ $status }}</option>
                                @endforeach
                            </select>
                        </td>
                    
            </tr>
            
        @endforeach
    </tbody>
</table>
<!-- <div class="modal" id="myModal">
                    <div class="modal-dialog">
                        <div class="modal-content">

                          Modal Header -->
<!-- <div class="modal-header">
                                <h4 class="modal-title">
                                    request
                                </h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div> -->

<!-- Modal body -->
<!-- <div class="modal-body">
                                <div class="mb-3" id="mainform">
                                    <div id="contant">
                                         
                                    </div>
                                </div>
                            </div> -->

<!-- Modal footer -->
<!-- <div class="modal-footer">
                                <button type="" class="btn btn-primary">yes</button>
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                               
                            </div>

                        </div>
                    </div>
                </div> -->