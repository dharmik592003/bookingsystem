<!doctype html>
<html lang="en">
<!--begin::Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>AdminLTE v4 | Dashboard</title>
    <!--begin::Primary Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="title" content="AdminLTE v4 | Dashboard" />
    <meta name="author" content="ColorlibHQ" />
    <meta name="csrf-token" content="{{csrf_token()}}">
    <meta name="description"
        content="AdminLTE is a Free Bootstrap 5 Admin Dashboard, 30 example pages using Vanilla JS." />
    <meta name="keywords"
        content="bootstrap 5, bootstrap, bootstrap 5 admin dashboard, bootstrap 5 dashboard, bootstrap 5 charts, bootstrap 5 calendar, bootstrap 5 datepicker, bootstrap 5 tables, bootstrap 5 datatable, vanilla js datatable, colorlibhq, colorlibhq dashboard, colorlibhq admin dashboard" />
    <!--end::Primary Meta Tags-->
    <!--begin::Fonts-->
    <link rel="stylesheet" href="{{asset('admin/dist/css/index.css')}}" />
    <!--end::Fonts-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="{{asset('admin/dist/css/overlayscrollbars.min.css')}}" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->
    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="{{asset('admin/dist/css/bootstrap-icons.min.css')}}" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->
    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="{{asset('admin/dist/css/adminlte.css')}}" />
    <!--end::Required Plugin(AdminLTE)-->
    <!-- apexcharts -->
    <link rel="stylesheet" href="{{asset('admin/dist/css/apexcharts.css')}}" />
    <!-- jsvectormap -->
    <link rel="stylesheet" href="{{asset('admin/dist/css/jsvectormap.min.css')}}" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" rel="Stylesheet"
        type="text/css" />
</head>
<!--end::Head-->
<!--begin::Body-->

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if(Session::has('fail'))
        <div class="alert alert-danger">
            {{Session::get('fail')}}
        </div>
    @elseif(Session::has('success')) 
        <div class="alert alert-success">
            {{Session::get('success')}}
        </div>
    @endif

    @csrf
    <div class="app-wrapper">
        <!--begin::Header-->
        @include('components.navbar')
        <!--end::Header-->
        <!--begin::Sidebar-->
        @if (Session::get('loginid') == 1)
            @include('components.sidebar')
        @else
            @include('components.sidebar-customer')
        @endif
        <!--end::Sidebar-->
        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                
                            <h3 class="mb-0">Available services</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content Header-->
            <!--begin::App Content-->
            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <!--begin::Col-->

                        <!--end::Col-->
                        <div class="col-lg-12 col-6">
                            <!--begin::Small Box Widget 2-->
                            <div class="small-box text-bg-primary">
                                <div class="inner">
                                    <h3>book your services</h3>
                                    <p></p>
                                    <svg class="small-box-icon" fill="currentColor" viewBox="0 0 24 24"
                                        xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                        <path
                                            d="M2.25 2.25a.75.75 0 000 1.5h1.386c.17 0 .318.114.362.278l2.558 9.592a3.752 3.752 0 00-2.806 3.63c0 .414.336.75.75.75h15.75a.75.75 0 000-1.5H5.378A2.25 2.25 0 017.5 15h11.218a.75.75 0 00.674-.421 60.358 60.358 0 002.96-7.228.75.75 0 00-.525-.965A60.864 60.864 0 005.68 4.509l-.232-.867A1.875 1.875 0 003.636 2.25H2.25zM3.75 20.25a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM16.5 20.25a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0z">
                                        </path>
                                    </svg>
                                </div>


                            </div>
                            <!--end::Small Box Widget 2-->
                        </div>
                        <!--end::Col-->


                    </div>


                    <section class="container">
                        <div class="row">
                            <div class="col-xl-4">
                                <div class="card" style="width: 18rem;">
                                    <img class="card-img-top" src="{{ asset($service->photo) }}" alt="Card image cap">
                                    <div class="card-body">
                                        <div class="card-text d-flex flex-column">
                                            <div class="card-title">
                                                <h5 class="card-title">{{ $service->name }}</h5>
                                            </div>
                                            <div class="card-details">
                                                <p class="card-text">{{$service->desc}}</p>
                                                <p class="card-text">{{$service->price}}</p>
                                                <p class="card-text">agency: {{$service->service->name}}</p>
                                            </div>
                                        </div>
                                        <a href="#" id="addtocart" class="btn btn-primary">add to cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-pull-7">

                                <form method="post" action="/{{$service->id}}/book">
                                    @csrf
                                    <div class="form-group">
                                        <span class="form-label">Service</span>
                                        <input class="form-control" value="{{ $service->name }}" type="text">
                                    </div>
                                    <div class="form-group">
                                        <span class="form-label">Price</span>
                                        <input class="form-control" value="{{ $service->price }}" type="text">
                                    </div>
                                    <div class="form-group">
                                        <span class="form-label">agency</span>
                                        <input class="form-control" value="{{$service->service->name}}" type="text">
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <span class="form-label">Check In</span>
                                                <input class="form-control date" name="from" type="text" required=""
                                                    id="from" disabled-dates="2025-2-25" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <span class="form-label">Check out</span>
                                                <input class="form-control date" name="to" type="text" id="to"
                                                    required="" autocomplete="off">
                                            </div>
                                        </div>

                                        <!-- <div class="col-sm-4">
                                                <input type="radio" class="btn-check" name="time[]" id="option1"
                                                    autocomplete="off" value="9Am-12PM">
                                                <label class="btn btn-secondary" for="option1">9Am-12PM</label>

                                                <input type="radio" class="btn-check" value="12PM-3PM" name="time[]"
                                                    id="option2" autocomplete="off">
                                                <label class="btn btn-secondary" for="option2">12PM-3PM</label>

                                                <input type="radio" class="btn-check" value="3PM-8PM" name="time[]"
                                                    id="option3" autocomplete="off">
                                                <label class="btn btn-secondary" for="option3">3PM-8PM</label>

                                                <input type="radio" class="btn-check" value="8PM-12AM" name="time[]"
                                                    id="option4" autocomplete="off">
                                                <label class="btn btn-secondary" for="option4">8PM-12AM</label>
                                            </div> -->

                                        <!-- <div class="col-xl-4">
                                                    <div class="time-picker" data-coreui-locale="en-US"
                                                        data-coreui-toggle="time-picker" id="timePicker1"></div>
                                                    <div class="time-picker" data-coreui-locale="en-US"
                                                        data-coreui-time="02:17:35 PM" data-coreui-toggle="time-picker"
                                                        id="timePicker2"></div>
                                            </div> -->


                                    </div>
                                    <div class="form-btn">
                                        <button type="submit" class="btn btn-primary">book now</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </section>
                </div>

                <div class="modal" id="myModal">
                    <div class="modal-dialog">
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title"></h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">

                                <div class="mb-3" id="mainform">
                                    <div id="contant">

                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>



                            </div>

                            <!-- Modal footer -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                            </div>

                        </div>
                    </div>
                </div>
        </main>

        @include('components.footer')

    </div>

    <script src="{{asset('/admin/dist/js/overlayscrollbars.browser.es6.min.js')}}"></script>

    <script src="{{asset('/admin/dist/js/popper.min.js')}}"></script>

    <script src="{{asset('/admin/dist/js/bootstrap.min.js')}}"></script>

    <script src="{{asset('/admin/dist/js/adminlte.js')}}"></script>

    <script>
        const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
        const Default = {
            scrollbarTheme: 'os-theme-light',
            scrollbarAutoHide: 'leave',
            scrollbarClickScroll: true,
        };
        document.addEventListener('DOMContentLoaded', function () {
            const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
            if (sidebarWrapper && typeof OverlayScrollbarsGlobal?.OverlayScrollbars !== 'undefined') {
                OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
                    scrollbars: {
                        theme: Default.scrollbarTheme,
                        autoHide: Default.scrollbarAutoHide,
                        clickScroll: Default.scrollbarClickScroll,
                    },
                });
            }
        });
    </script>

    <script src="{{asset('admin/dist/js/Sortable.min.js')}}"></script>

    <script>
        const connectedSortables = document.querySelectorAll('.connectedSortable');
        connectedSortables.forEach((connectedSortable) => {
            let sortable = new Sortable(connectedSortable, {
                group: 'shared',
                handle: '.card-header',
            });
        });

        const cardHeaders = document.querySelectorAll('.connectedSortable .card-header');
        cardHeaders.forEach((cardHeader) => {
            cardHeader.style.cursor = 'move';
        });
    </script>
    <!-- apexcharts -->
    <script src="{{asset('admin/dist/js/apexcharts.min.js')}}"
        integrity="sha256-+vh8GkaU7C9/wbSLIcwq82tQ2wTf44aOHA8HlBMwRI8=" crossorigin="anonymous">
        </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js" type="text/javascript"></script>
    <script>
        $(document).ready(function () {
            jQuery.browser = {};
            (function () {
                jQuery.browser.msie = false;
                jQuery.browser.version = 0;
                if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
                    jQuery.browser.msie = true;
                    jQuery.browser.version = RegExp.$1;
                }
            })();
            const mindates = [];
            const maxdates = [];
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                },
                type: "get",
                url: "/" + {{$service->id}} + "/aviablity",
                success: function (data) {
                    if (data.length != 0) {
                        for (let i = 0; i < (data.date).length; i++) {
                            console.log(data.date[i].from);
                            mindates.push(data.date[i].from);
                            maxdates.push(data.date[i].to);
                        }
                        console.log(maxdates)
                        console.log(mindates)
                        function noSundaysOrHolidays(date) {
                            var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
                            return [mindates.indexOf(string) == -1 && maxdates.indexOf(string) == -1]
                        }

                        $("#from").datepicker({
                            dateFormat: 'yy-mm-dd',
                            multidate: true,
                            beforeShowDay: function (date) {
                                $thisDate = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
                                var day = date.getDay();
                                if ($.inArray($thisDate, mindates) == -1 && day != 5 && day != 6) {
                                    return [true, ""];
                                } else {
                                    return [false, "", "Unavailable"];
                                }
                            }
                            // beforeShowDay: noSundaysOrHolidays,

                        });
                        $("#to").datepicker({
                            dateFormat: 'yy-mm-dd',
                            multidate: true,
                            beforeShowDay: function (date) {
                                $thisDate = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
                                var day = date.getDay();
                                if ($.inArray($thisDate, maxdates) == -1 && day != 5 && day != 6) {
                                    return [true, ""];
                                } else {
                                    return [false, "", "Unavailable"];
                                }
                            }
                            // beforeShowDay: noSundaysOrHolidays,
                        });
                    }
                    else {
                        $("#from").datepicker({
                            dateFormat: 'yy-mm-dd',
                            minDate:0
                        }) ;
                        $("#to").datepicker({
                            dateFormat: 'yy-mm-dd',
                        });
                        $('#from').change(function () {
                            startDate = $(this).datepicker('getDate');
                            $("#to").datepicker("option", "minDate", startDate);
                        })
                        $('#to').change(function () {
                            endDate = $(this).datepicker('getDate');
                            $("#from").datepicker("option", "maxDate", endDate);
                        })
                    }

                }
            });
        });

    </script>
  
    <script src="{{asset('admin/dist/js/jsvectormap.min.js')}}"></script>
    <script src="{{asset('admin/dist/js/world.js')}}"></script>
</body>

</html>