



  <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <!--begin::Sidebar Brand-->
    <div class="sidebar-brand">
      <!--begin::Brand Link-->
      <a href="/" class="brand-link">
        <!--begin::Brand Image-->
        <img
          data-w-id="901947e3-9f91-e281-ec5c-89b6504c1a15" loading="lazy" alt=""
          src="{{asset('img/661681f6c60839d5881a158b-66181275e25270cd7740cda0_Logo.svg')}}" class="white-logo">
        <!--end::Brand Text-->
      </a>
      <!--end::Brand Link-->
    </div>
    <!--end::Sidebar Brand-->
    <!--begin::Sidebar Wrapper-->
    <div class="sidebar-wrapper">
      <nav class="mt-2">
        <!--begin::Sidebar Menu-->
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">

          <li class="nav-item">
            <a href="/dashboard" class="nav-link">
              <i class="nav-icon bi bi-palette"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="/services" class="nav-link">
            <i class="bi bi-x-diamond-fill"></i>
              <p>Services</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="/requests" class="nav-link">
              <i class="nav-icon bi bi-download"></i>
              <p>Requests</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="/cart" class="nav-link">
            <i class="bi bi-cart2"></i>
              <p>Cart</p>
            </a>
          </li>

        </ul>
        <!--end::Sidebar Menu-->
      </nav>
    </div>
    <!--end::Sidebar Wrapper-->
  </aside>
