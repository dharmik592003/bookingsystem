<nav class="app-header navbar navbar-expand bg-body">
    <!--begin::Container-->
    <div class="container-fluid">

    <!-- <ul> -->
    <!-- <a href="/" class="brand-link"> -->
        <!--begin::Brand Image-->
        <!-- <img data-w-id="901947e3-9f91-e281-ec5c-89b6504c1a15" loading="lazy" alt="" src="{{asset('img/Group 1.svg')}}" class="white-logo"> -->
        <!--end::Brand Text-->
      <!-- </a> -->
    <!-- </ul> -->
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link" href="#" data-lte-toggle="fullscreen">
                    <i data-lte-icon="maximize" class="bi bi-arrows-fullscreen"></i>
                    <i data-lte-icon="minimize" class="bi bi-fullscreen-exit" style="display: none"></i>
                </a>
            </li>
            <li class="nav-item dropdown user-menu">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img src="{{asset('admin/dist/assets/img/user.webp')}}" class="user-image rounded-circle shadow"
                        alt="User Image" />
                    <span class="d-none d-md-inline">{{ $user->name }}</span>
                </a>
                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                    <!--begin::User Image-->
                    <li class="user-header text-bg-primary">
                        <img src="{{asset('admin/dist/assets/img/user.webp')}}" class="rounded-circle shadow"
                            alt="User Image" />
                        <p>
                            {{ $user->name }}
                            <small>Member since {{ $user->created_at }}</small>
                        </p>
                    </li>

                    <li class="user-footer">

                        <a href="/logout" class="btn btn-default btn-flat float-end">Sign out</a>
                    </li>
                    <!--end::Menu Footer-->
                </ul>
            </li>
       </ul>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                    <i class="bi bi-list"></i>
                </a>
            </li>

        </ul>
        <!--end::End Navbar Links-->
    </div>
    <!--end::Container-->
</nav>
